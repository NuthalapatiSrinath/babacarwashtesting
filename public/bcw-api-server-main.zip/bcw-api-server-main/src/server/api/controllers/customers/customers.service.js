const CustomersModel = require('../../models/customers.model')
const LocationsModel = require('../locations/locations.model')
const BuildingsModel = require('../../models/buildings.model')
const WorkersModel = require('../../models/workers.model')
const ImportLogsModel = require('../../models/import-logs.model')
const CounterService = require('../../../utils/counters')
const CommonHelper = require('../../../helpers/common.helper')
const JobsService = require('../../staff/jobs/jobs.service')
const JobsModel = require('../../models/jobs.model')
const moment = require('moment')
const service = module.exports

service.list = async (userInfo, query) => {

    const paginationData = CommonHelper.paginationData(query)
    const findQuery = {
        isDeleted: false,
        "vehicles.status": Number(query.status) || 1,
        ...(query.search ? {
            $or: [
                { mobile: { $regex: query.search, $options: 'i' } },
                { flat_no: { $regex: query.search, $options: 'i' } },
                { "vehicles.registration_no": { $regex: query.search, $options: 'i' } },
                { "vehicles.parking_no": { $regex: query.search, $options: 'i' } },
            ]
        } : null)
    }

    if (query.search) {

        const buildings = await BuildingsModel.find({ isDeleted: false, name: { $regex: query.search, $options: 'i' } }, { _id: 1 }).lean()

        if (buildings.length) {
            findQuery.$or.push({ building: { $in: buildings.map(e => e._id.toString()) } })
        }

        const workers = await WorkersModel.find({ isDeleted: false, name: { $regex: query.search, $options: 'i' } }, { _id: 1 }).lean()

        if (workers.length) {
            findQuery.$or.push({ "vehicles.worker": { $in: workers.map(e => e._id.toString()) } })
        }

    }

    const total = await CustomersModel.aggregate([
        { $match: findQuery },
        {
            $group: {
                _id: null,
                total: { $sum: { $size: "$vehicles" } }
            }
        }
    ])

    const data = await CustomersModel.find(findQuery)
        .sort({ _id: -1 })
        .skip(paginationData.skip)
        .limit(paginationData.limit)
        .populate([{
            path: 'building',
            model: 'buildings',
            populate: [
                { path: 'location_id', model: 'locations' }
            ]
        }, {
            path: 'vehicles.worker',
            model: 'workers'
        }])
        .lean()

    for (const iterator of data) {
        iterator.vehicles = iterator.vehicles.filter(e => e.status == (Number(query.status) || 1))
    }

    return { total: total.length ? total[0].total : null, data }

}

service.info = async (userInfo, id) => {
    return CustomersModel.findOne({ _id: id, isDeleted: false }).lean()
}

service.create = async (userInfo, payload) => {
    const findUserQuery = { isDeleted: false, $or: [{ mobile: payload.mobile }] }
    if (payload.email) {
        findUserQuery.$or.push({ email: payload.email })
    }
    const userExists = await CustomersModel.countDocuments(findUserQuery)
    if (userExists) {
        throw "USER-EXISTS"
    }
    const id = await CounterService.id("customers")
    const data = { createdBy: userInfo._id, updatedBy: userInfo._id, id, ...payload }
    const customerData = await new CustomersModel(data).save()
    await JobsService.createJob(customerData)
}

service.update = async (userInfo, id, payload) => {
    const vehicle = payload.vehicles[0]
    delete payload.vehicles
    await CustomersModel.updateOne({ _id: id }, { $set: payload })
    await CustomersModel.updateOne({ _id: id, "vehicles._id": vehicle._id }, { $set: { "vehicles.$": vehicle } })
    const customerData = await CustomersModel.findOne({ _id: id }).lean()
    await JobsService.createJob(customerData)
}

service.delete = async (userInfo, id, payload) => {
    return await CustomersModel.updateOne({ _id: id }, { isDeleted: true, deletedBy: userInfo._id })
}

service.undoDelete = async (userInfo, id) => {
    return await CustomersModel.updateOne({ _id: id }, { isDeleted: false, updatedBy: userInfo._id })
}

service.vehicleDeactivate = async (userInfo, id, payload) => {
    await CustomersModel.updateOne({ "vehicles._id": id }, {
        $set: {
            "vehicles.$.status": 2,
            "vehicles.$.deactivateReason": payload.deactivateReason,
            "vehicles.$.deactivateDate": payload.deactivateDate,
            "vehicles.$.deactivatedBy": userInfo._id
        }
    })
}

service.vehicleActivate = async (userInfo, id, payload) => {
    await CustomersModel.updateOne({ "vehicles._id": id }, {
        $set: {
            "vehicles.$.status": 1,
            "vehicles.$.start_date": payload.start_date,
            "vehicles.$.activatedBy": userInfo._id
        }
    })
}

service.deactivate = async (userInfo, id, payload) => {
    await CustomersModel.updateOne({ _id: id }, { $set: { status: 2, ...payload } })
}

service.archive = async (userInfo, id, payload) => {
    await CustomersModel.updateOne({ _id: id }, { $set: { status: 9 } })
}

service.importData = async (userInfo, body) => {

    const buildPayload = {
        customer: (data, location, building) => {
            return {
                mobile: data.mobile,
                ...(data.flat_no ? { flat_no: data.flat_no } : null),
                ...(data.firstName ? { firstName: data.firstName } : null),
                ...(data.lastName ? { lastName: data.lastName } : null),
                ...(data.email ? { email: data.email } : null),
                ...(location ? { location: location._id } : null),
                ...(building ? { building: building._id } : null),
                imported: true
            }
        },
        vehicle: (data, worker) => {

            const schedule_days = []

            if (data.schedule_type.toLowerCase() == 'weekly') {
                for (const day of data.schedule_days.split(",")) {
                    let dayValue = day.trim()
                    schedule_days.push({ day: dayValue, value: CommonHelper.getDayNumber(dayValue) })
                }
            }

            return {
                registration_no: data.registration_no,
                parking_no: data.parking_no,
                worker: worker._id,
                amount: data.amount,
                schedule_type: data.schedule_type,
                schedule_days,
                start_date: data.start_date,
                advance_amount: data.advance_amount,
            }

        }
    }

    if (body.csvData && body.csvData.data.length) {

        const counts = {
            duplicates: [],
            errors: [],
            success: 0
        }

        for (const iterator of body.csvData.data) {
            try {

                const findUserQuery = { isDeleted: false, $or: [{ mobile: iterator.mobile }] }

                if (iterator.email) {
                    findUserQuery.$or.push({ email: iterator.email })
                }

                if (!moment(iterator.start_date, CommonHelper.detectDateFormat(iterator.start_date), true).isValid()) {
                    throw `Invalid start date format`
                }

                if (["daily", "weekly"].indexOf(iterator.schedule_type.toLowerCase()) == -1) {
                    throw `Invalid schedule type`
                }

                const location = await LocationsModel.findOne({
                    isDeleted: false,
                    address: { $regex: new RegExp(iterator.location.trim(), 'i') }
                })

                if (!location) {
                    throw `Location: ${iterator.location} not found`
                }

                const building = await BuildingsModel.findOne({
                    isDeleted: false,
                    name: { $regex: new RegExp(iterator.building.trim(), 'i') }
                })

                if (!building) {
                    throw `Building: ${iterator.building} not found`
                }

                const worker = await WorkersModel.findOne({
                    isDeleted: false,
                    name: { $regex: new RegExp(iterator.worker.trim(), 'i') }
                })

                if (!worker) {
                    throw `Worker: ${iterator.worker} not found`
                }

                let customerInfo = await CustomersModel.findOne(findUserQuery)
                let addVehicle = false

                if (customerInfo) {

                    const customerUpdateData = buildPayload.customer(iterator, location, building)
                    await CustomersModel.updateOne({ _id: customerInfo._id }, { $set: customerUpdateData })

                    const vehicleInfo = await CustomersModel.findOne({
                        _id: customerInfo._id,
                        "vehicles.registration_no": iterator.registration_no
                    }).lean()

                    if (vehicleInfo) {
                        const vehicleId = vehicleInfo.vehicles.find(e => e.registration_no == iterator.registration_no)
                        const vehicleUpdateData = buildPayload.vehicle(iterator, worker)
                        const res = await CustomersModel.updateOne({ "vehicles._id": vehicleId._id }, {
                            $set: {
                                "vehicles.$": vehicleUpdateData
                            }
                        })
                        continue
                    }

                    addVehicle = true

                }

                const vehicleInfo = buildPayload.vehicle(iterator, worker)

                if (addVehicle) {
                    await CustomersModel.updateOne({ _id: customerInfo._id }, { $push: { vehicles: vehicleInfo } })
                } else {

                    const customer = {
                        ...buildPayload.customer(iterator, location, building),
                        vehicles: [vehicleInfo],
                    }

                    const id = await CounterService.id("customers")
                    const data = { createdBy: userInfo._id, updatedBy: userInfo._id, id, ...customer }

                    customerInfo = await new CustomersModel(data).save()

                }

                await JobsService.createJob(customerInfo, 'Import API')

                counts.success++

            } catch (error) {
                console.error(error)
                counts.errors.push({ ...iterator, error: error.message || error })
            }

        }

        const importLog = await new ImportLogsModel({ type: "customers-import", logs: counts }).save()

        return { _id: importLog._id, ...counts }

    } else {
        throw "No data in the file"
    }
}

service.exportData = async (userInfo, query) => {
    const findQuery = { isDeleted: false }
    const customerData = await CustomersModel.find(findQuery, {
        _id: 0,
        "vehicles._id": 0,
        createdBy: 0,
        updatedBy: 0,
        isDeleted: 0,
        updatedAt: 0,
        id: 0,
        status: 0,
        status: 0,
        createdAt: 0
    })
        .sort({ _id: -1 })
        .populate([
            { path: 'location', model: 'locations' },
            { path: 'building', model: 'buildings' },
            { path: 'vehicles.worker', model: 'workers' }
        ])
        .lean()
    const exportMap = []
    for (const iterator of customerData) {
        for (const vehicle of iterator.vehicles) {
            let customer = {
                ...iterator,
                ...vehicle,
                building: iterator.building.name,
                location: iterator.location.address,
                worker: vehicle.worker.name,
                schedule_days: vehicle.schedule_type == 'weekly' ? vehicle.schedule_days.map(e => e.day).join(', ') : "",
                start_date: moment(vehicle.start_date).format('YYYY-MM-DD'),
                createdAt: moment(vehicle.start_date).format('YYYY-MM-DD'),
            }
            delete customer.vehicles
            exportMap.push(customer)
        }
    }
    return exportMap
}

service.washesList = async (userInfo, query, customerId) => {

    const paginationData = CommonHelper.paginationData(query)
    const findQuery = {
        isDeleted: false,
        customer: customerId,
        ...(query.startDate ? {
            createdAt: { $gte: new Date(query.startDate), $lte: new Date(query.endDate) }
        } : null),
        ...(query.search ? {
            $or: [{ name: { $regex: query.search, $options: 'i' } }]
        } : null)
    }

    const total = await JobsModel.countDocuments(findQuery)
    const data = await JobsModel.find(findQuery)
        .sort({ _id: -1 })
        .skip(paginationData.skip)
        .limit(paginationData.limit)
        .populate([
            { path: 'building', model: 'buildings' },
            { path: 'location', model: 'locations' },
            { path: 'mall', model: 'malls' },
            { path: 'customer', model: 'customers' }
        ])
        .lean()

    for (const iterator of data) {
        iterator.vehicle = iterator.customer.vehicles.find(e => e._id == iterator.vehicle)
    }

    return { total, data }

}

service.exportWashesList = async (userInfo, query) => {

    const findQuery = {
        isDeleted: false,
        customer: customerId,
        ...(query.startDate ? {
            createdAt: { $gte: new Date(query.startDate), $lte: new Date(query.endDate) }
        } : null),
        ...(query.search ? {
            $or: [{ name: { $regex: query.search, $options: 'i' } }]
        } : null)
    }

    const data = await JobsModel.find(findQuery)
        .sort({ _id: -1 })
        .skip(paginationData.skip)
        .limit(paginationData.limit)
        .populate([
            { path: 'building', model: 'buildings' },
            { path: 'location', model: 'locations' },
            { path: 'mall', model: 'malls' },
            { path: 'customer', model: 'customers' }
        ])
        .lean()

    for (const iterator of data) {
        iterator.vehicle = iterator.customer.vehicles.find(e => e._id == iterator.vehicle)
    }

    const exportMap = []

    for (const iterator of data) {
        let customer = {
            ...iterator,
            ...vehicle,
            building: iterator.building.name,
            location: iterator.location.address,
            worker: vehicle.worker.name,
            schedule_days: vehicle.schedule_type == 'weekly' ? vehicle.schedule_days.map(e => e.day).join(', ') : "",
            start_date: moment(vehicle.start_date).format('YYYY-MM-DD'),
            createdAt: moment(vehicle.start_date).format('YYYY-MM-DD'),
        }
        delete customer.vehicles
        exportMap.push(customer)
    }

    return exportMap

}
