const moment = require('moment');
const exceljs = require('exceljs');

const PaymentsModel = require('../../models/payments.model')
const PaymentSettlementsModel = require('../../models/payment-settlements.model')
const TransactionsModel = require('../../models/transactions.model')
const WorkersModel = require('../../models/workers.model')
const CounterService = require('../../../utils/counters')
const CommonHelper = require('../../../helpers/common.helper')

const service = module.exports

service.list = async (userInfo, query) => {

    const paginationData = CommonHelper.paginationData(query)
    const findQuery = {
        isDeleted: false,
        ...(query.startDate ? { createdAt: { $gte: new Date(query.startDate), $lte: new Date(query.endDate) } } : null),
        onewash: query.onewash == 'true',
        ...(query.status ? { status: query.status } : null),
        ...(query.worker ? { worker: query.worker } : null),
        ...(query.building ? { building: query.building } : null),
        ...(query.mall ? { mall: query.mall } : null),
        ...(query.search ? {
            $or: [
                { "vehicle.registration_no": { $regex: query.search, $options: 'i' } },
                { "vehicle.parking_no": { $regex: query.search, $options: 'i' } }
            ]
        } : null)
    }
    const total = await PaymentsModel.countDocuments(findQuery)
    const data = await PaymentsModel.find(findQuery)
        .sort({ _id: -1 })
        .skip(paginationData.skip)
        .limit(paginationData.limit)
        .populate([
            {
                path: 'customer',
                model: 'customers',
                populate: [{ path: 'building', model: 'buildings' }]
            },
            { path: 'job', model: 'jobs' },
            { path: 'worker', model: 'workers' },
            { path: 'mall', model: 'malls' }
        ])
        .lean()

    const totalPayments = await PaymentsModel.aggregate([{ $match: findQuery }, { $group: { _id: "$payment_mode", amount: { $sum: "$amount_paid" } } }])
    const totalAmount = totalPayments.length ? totalPayments.reduce((p, c) => p + c.amount, 0) : 0
    const cash = totalPayments.length ? totalPayments.filter(e => e._id == 'cash') : 0
    const card = totalPayments.length ? totalPayments.filter(e => e._id == 'card') : 0
    const bank = totalPayments.length ? totalPayments.filter(e => e._id == 'bank transfer') : 0
    const counts = {
        totalJobs: total,
        totalAmount,
        cash: cash.length ? cash[0].amount : 0,
        card: card.length ? card[0].amount : 0,
        bank: bank.length ? bank[0].amount : 0
    }

    return { total, data, counts }

}

service.info = async (userInfo, id) => {
    return PaymentsModel.findOne({ _id: id, isDeleted: false }).lean()
}

service.create = async (userInfo, payload) => {
    const id = await CounterService.id("payments")
    const data = { createdBy: userInfo._id, updatedBy: userInfo._id, id, ...payload }
    await new PaymentsModel(data).save()
}

service.update = async (userInfo, id, payload) => {
    await PaymentsModel.updateOne({ _id: id }, { $set: payload })
}

service.delete = async (userInfo, id, payload) => {
    return await PaymentsModel.updateOne({ _id: id }, { isDeleted: true, deletedBy: userInfo._id })
}

service.undoDelete = async (userInfo, id) => {
    return await PaymentsModel.updateOne({ _id: id }, { isDeleted: false, updatedBy: userInfo._id })
}

service.updatePayment = async (userInfo, id, payload) => {
    const updatePayload = {
        $set: {
            total_amount: payload.total_amount,
            notes: payload.notes
        }
    }
    await PaymentsModel.updateOne({ _id: id }, updatePayload)
}

service.collectPayment = async (userInfo, id, payload) => {

    const paymentData = await PaymentsModel.findOne({ _id: id }).lean()

    let status = Number(payload.amount) < (paymentData.amount_charged - paymentData.amount_paid) ? 'pending' : 'completed'
    let balance = (paymentData.amount_charged + paymentData.old_balance) - (paymentData.amount_paid + payload.amount)

    await PaymentsModel.updateOne({ _id: id }, {
        $set: {
            amount_paid: Number(paymentData.amount_paid + payload.amount),
            payment_mode: payload.payment_mode,
            balance,
            status, collectedDate: payload.payment_date
        }
    })

    await new TransactionsModel({
        payment: id, amount: Number(payload.amount),
        payment_date: payload.payment_date,
        createdBy: userInfo._id,
        updatedBy: userInfo._id
    }).save()

}

service.settlements = async (userInfo, query) => {
    const paginationData = CommonHelper.paginationData(query)
    const findQuery = {
        isDeleted: false,
        ...(userInfo.role == 'supervisor' ? { supervisor: userInfo._id } : null)
    }
    const total = await PaymentSettlementsModel.countDocuments(findQuery)
    const data = await PaymentSettlementsModel.find(findQuery)
        .sort({ _id: -1 })
        .skip(paginationData.skip)
        .limit(paginationData.limit)
        .populate('supervisor payments')
        .lean()
    for (const iterator of data) {
        iterator.amount = iterator.payments.reduce((p, c) => p + c.amount_paid, 0)
        iterator.cash = iterator.payments.filter(e => e.payment_mode == 'cash').reduce((p, c) => p + c.amount_paid, 0)
        iterator.card = iterator.payments.filter(e => e.payment_mode == 'card').reduce((p, c) => p + c.amount_paid, 0)
        iterator.bank = iterator.payments.filter(e => e.payment_mode == 'bank transfer').reduce((p, c) => p + c.amount_paid, 0)
    }
    return { total, data }
}

service.updateSettlements = async (id, userInfo, payload) => {
    return PaymentSettlementsModel.updateOne({ _id: id }, { $set: { status: 'completed', updatedBy: userInfo._id } })
}

service.settlePayment = async (userInfo, id, payload) => {
    await PaymentsModel.updateMany({ _id: { $in: payload.paymentIds } }, {
        $set: {
            settled: 'completed',
            settledDate: new Date()
        }
    })
}

service.exportData = async (userInfo, query) => {

    const findQuery = {
        isDeleted: false,
        ...(query.startDate ? { createdAt: { $gte: new Date(query.startDate), $lte: new Date(query.endDate) } } : null),
        onewash: query.onewash == 'true',
        ...(query.status ? { status: query.status } : null),
        ...(query.worker ? { worker: query.worker } : null),
        ...(query.building ? { building: query.building } : null),
        ...(query.mall ? { mall: query.mall } : null),
        ...(query.search ? { $or: [{ "vehicle.registration_no": query.search }, { "vehicle.parking_no": query.search }] } : null)
    }

    const data = await PaymentsModel.find(findQuery, {
        _id: 0,
        isDeleted: 0,
        createdBy: 0,
        updatedBy: 0,
        id: 0,
        updatedAt: 0,
        onewash: 0,
        amount_paid: 0,
        job: 0,
        location: 0
    })
        .sort({ _id: -1 })
        .populate([
            { path: 'customer', model: 'customers' },
            { path: 'job', model: 'jobs' },
            { path: 'worker', model: 'workers' },
            { path: 'mall', model: 'malls' },
            { path: 'building', model: 'buildings' },
        ])
        .lean()

    const workbook = new exceljs.Workbook();
    const worksheet = workbook.addWorksheet('Report');
    const keys = Object.keys(data[0]);

    worksheet.addRow(keys);

    for (const iterator of data) {

        iterator.createdAt = moment(iterator.createdAt).format('YYYY-MM-DD')
        iterator.vehicle = iterator?.vehicle?.registration_no || ''
        iterator.parking_no = iterator?.vehicle?.parking_no || ''
        iterator.worker = iterator?.worker?.name
        iterator.customer = iterator?.customer?.mobile
        iterator.mall = iterator?.mall?.name || ''
        iterator.building = iterator?.building?.name || ''

        const values = [];

        for (const key of keys) {
            values.push(iterator[key] !== undefined ? iterator[key] : '')
        }

        worksheet.addRow(values);

    }

    return workbook

}

service.monthlyStatement = async (userInfo, query) => {

    const findQuery = {
        isDeleted: false,
        onewash: false,
        createdAt: {
            $gte: moment(new Date(query.year, query.month, 1)).startOf('month').subtract(1, 'day').utc().format(),
            $lte: moment(new Date(query.year, query.month, 1)).endOf('month').utc().format()
        }
    }

    if (query.worker != 'all') {
        findQuery.worker = query.worker
    } else if (query.building != 'all') {
        const workers = await WorkersModel.find({ isDeleted: false, buildings: query.building }, { _id: 1 }).lean()
        findQuery.worker = { $in: workers.map(e => e._id) }
    }

    const data = await PaymentsModel.find(findQuery, {
        id: 0,
        status: 0,
        isDeleted: 0,
        createdBy: 0,
        updatedBy: 0,
        updatedAt: 0,
    })
        .sort({ _id: -1 })
        .populate([
            { path: 'job', model: 'jobs' },
            { path: 'worker', model: 'workers' },
            { path: 'building', model: 'buildings' },
            { path: 'customer', model: 'customers' }
        ])
        .lean()

    const workbook = new exceljs.Workbook();

    const buildingsMap = {}
    const buildingWorkerMap = {}

    for (const iterator of JSON.parse(JSON.stringify(data))) {
        if (iterator.building && iterator.worker) {
            if (buildingWorkerMap[iterator.building._id]) {
                if (buildingWorkerMap[iterator.building._id][iterator.worker._id]) {
                    buildingWorkerMap[iterator.building._id][iterator.worker._id].push(iterator)
                } else {
                    buildingWorkerMap[iterator.building._id][iterator.worker._id] = [iterator]
                }
            } else {
                buildingsMap[iterator.building._id] = iterator.building
                buildingWorkerMap[iterator.building._id] = { [iterator.worker._id]: [iterator] }
            }
        }
    }

    const keys = ['Sl. No', 'Parking No.', 'Registration No.', 'Mobile No.', 'Flat No.', 'Start Date', 'Schedule', 'Advance', 'Current Month', 'Last Month', 'Total', 'Paid', 'Notes', 'Due Date'];

    for (const building in buildingWorkerMap) {

        let count = 1

        const buildingInfo = buildingsMap[building]
        const workersData = buildingWorkerMap[building]
        const reportSheet = workbook.addWorksheet(buildingInfo.name);

        for (const worker in workersData) {

            const workerData = workersData[worker]

            reportSheet.addRow([workerData[0].worker.name, buildingInfo.name]);
            reportSheet.addRow(keys);

            for (const payment of workerData) {
                let vehicle = payment.customer.vehicles.find(e => e.registration_no == payment.vehicle.registration_no)
                reportSheet.addRow([
                    count++,
                    payment.vehicle.parking_no,
                    payment.vehicle.registration_no,
                    payment.customer.mobile,
                    payment.customer.flat_no,
                    vehicle ? moment(vehicle.start_date).format('DD-MM-YYYY') : '',
                    vehicle ? (vehicle.schedule_type == 'daily' ? 'D' : `W${vehicle.schedule_days.length}`) : '',
                    vehicle ? vehicle.advance_amount ? 'A' : '' : '',
                    payment.amount_charged,
                    payment.old_balance,
                    (payment.total_amount) - payment.amount_paid,
                    payment.amount_paid,
                    payment.notes,
                    moment(payment.createdAt).tz('Asia/Dubai').add(1, 'month').format('DD-MM-YYYY')
                ]);
            }

        }

    }

    return workbook

}
