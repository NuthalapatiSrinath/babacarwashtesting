const router = require('express').Router()
const controller = require('./webhooks.controller')

module.exports = router
