const StaffModel = require('../../models/staff.model')
const CounterService = require('../../../utils/counters')
const CommonHelper = require('../../../helpers/common.helper')
const AuthHelper = require('../auth/auth.helper')
const service = module.exports

service.list = async (userInfo, query) => {

    const paginationData = CommonHelper.paginationData(query)
    const findQuery = {
        isDeleted: false,
        ...(query.search ? {
            $or: [
                { name: { $regex: query.search, $options: 'i' } }
            ]
        } : null)
    }

    const total = await StaffModel.countDocuments(findQuery)
    const data = await StaffModel.find(findQuery)
        .sort({ _id: -1 })
        .skip(paginationData.skip)
        .limit(paginationData.limit)
        .populate('site')
        .lean()

    return { total, data }

}

service.info = async (userInfo, id) => {
    return StaffModel.findOne({ _id: id, isDeleted: false }).lean()
}

service.create = async (userInfo, payload) => {
    const userExists = await StaffModel.countDocuments({ isDeleted: false, employeeCode: payload.employeeCode })
    if (userExists) {
        throw "USER-EXISTS"
    }
    const id = await CounterService.id("staff")
    const data = { createdBy: userInfo._id, updatedBy: userInfo._id, id, ...payload }
    await new StaffModel(data).save()
}

service.update = async (userInfo, id, payload) => {
    const isExists = await StaffModel.countDocuments({ _id: { $ne: id }, isDeleted: false, employeeCode: payload.employeeCode })
    if (isExists) {
        throw "Oops! Employee already exists"
    }
    const data = { updatedBy: userInfo._id, ...payload }
    await StaffModel.updateOne({ _id: id }, { $set: data })
}

service.delete = async (userInfo, id, payload) => {
    return await StaffModel.updateOne({ _id: id }, { isDeleted: true, deletedBy: userInfo._id })
}

service.undoDelete = async (userInfo, id) => {
    return await StaffModel.updateOne({ _id: id }, { isDeleted: false, updatedBy: userInfo._id })
}
