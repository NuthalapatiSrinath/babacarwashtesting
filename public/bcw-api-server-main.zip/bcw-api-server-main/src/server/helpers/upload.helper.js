const fs = require('fs');
const formidable = require('formidable');
const CSVHandler = require('../handlers/file/csv.handler')
const UploadHelper = module.exports

UploadHelper.upload = async (req, res, next) => {

    const files = [], fields = {};
    const formData = new formidable.IncomingForm();

    formData.keepExtensions = true;
    formData
        .on('field', function (field, value) {
            fields[field] = value;
        }).on('file', function (field, file) {
            files.push({ file, key: field });
        }).on('end', async function () {
            req.body = fields;
            req.files = files;
            return next()
        }).on('error', (error) => {
            console.error(error)
            return res.status(500).json({ statusCode: 500, message: 'Internal server error', error })
        })

    formData.parse(req)

}


UploadHelper.readUpload = function (req, res, next) {
    const form = new formidable.IncomingForm();
    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(500).json({ message: 'Internal server error' })
        }
        const csvData = []
        CSVHandler.read(files.file.path)
            .on('data', async (data) => {
                let parseData = {}
                for (const key in data) {
                    parseData[key.trim()] = data[key]
                }
                csvData.push(parseData)
            })
            .on('end', async () => {
                req.body.csvData = { data: csvData, fields }
                fs.unlinkSync(files.file.path)
                return next()
            })
    })
}