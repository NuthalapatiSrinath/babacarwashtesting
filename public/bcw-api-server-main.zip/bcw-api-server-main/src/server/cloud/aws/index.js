const AWS = require('aws-sdk')
const formidable = require('formidable');
const fs = require('fs');
const config = require('../../utils/config')

const AWSHandler = module.exports

AWS.config.update({
    accessKeyId: config.AWS.id,
    secretAccessKey: config.AWS.key
})

const s3 = new AWS.S3();

AWSHandler.upload = async (userInfo, file) => {
    try {

        const body = fs.readFileSync(file.path)
        const fileName = `${config.env}/${userInfo && userInfo._id + '/' ? userInfo._id + '/' : ''}${Date.now().toString()}_${file.name}`
        const params = {
            Bucket: config.AWS.bucket,
            Key: fileName,
            Body: body,
            ContentEncoding: 'base64',
            ContentType: file.type,
            ACL: 'public-read'
        };
        const result = await s3.upload(params).promise();

        return result.Location

    } catch (error) {
        console.error(error)
        throw error
    }
}

AWSHandler.UploadImages = (req, res, next) => {
    try {

        const { user } = req
        const formData = formidable.IncomingForm();
        const files = [], fields = {};

        formData.keepExtensions = true;
        formData
            .on('field', function (field, value) {
                fields[field] = value;
            })
            .on('file', function (field, file) {
                files.push({ file, key: field });
            })
            .on('end', async function () {

                const paths = []

                for (let i of files) {
                    const location = await AWSHandler.upload(user, i.file)
                    fs.unlinkSync(i.file.path)
                    paths.push({ key: i.key, path: location, name: i.file.name })
                }

                req.body = fields;
                req.files = paths;

                return next()

            })
            .on('error', (error) => {
                console.error(error)
                return res.status(500).json({ statusCode: 500, message: 'Internal server error', error })
            })

        formData.parse(req)

    } catch (error) {
        console.error(error)
        return res.status(500).json({ statusCode: 500, message: 'Internal server error', error })
    }

}