module.exports = {
    aws: require('./aws/index')
}