const events = module.exports

events.signup = async (userInfo) => {
    try {
    } catch (error) {
        console.error(error)
    }
}