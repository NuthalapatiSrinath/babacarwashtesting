export const environment = {
    production: false,
    hmr       : true,
    domain : 'http://13.234.169.162'
};
