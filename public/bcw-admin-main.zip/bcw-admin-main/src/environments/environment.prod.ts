export const environment = {
    production: true,
    hmr: false,
    // domain: 'https://babacarwash.ae'//prod
    domain: 'http://3.29.249.5:3000' // google

};
