export class UserRoles {
    static SUPER_ADMIN = 'super_admin';
    static ADMIN = 'admin';
//     static USER = 'user';
//     static GUARD = 'guard';
//     static APP_ADMIN = 'app_admin';
//     static ALL = ['admin', 'super_admin', 'user', 'guard', 'app_admin'];
 }